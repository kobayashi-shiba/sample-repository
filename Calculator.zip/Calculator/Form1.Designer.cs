﻿namespace Calculator
{
    partial class Calculator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Input_1 = new Button();
            Input_2 = new Button();
            Operator_plus = new Button();
            Operator_equal = new Button();
            Input_3 = new Button();
            Input_4 = new Button();
            Input_5 = new Button();
            Input_6 = new Button();
            Input_7 = new Button();
            Input_8 = new Button();
            Input_9 = new Button();
            Input_0 = new Button();
            operator_minus = new Button();
            operator_multi = new Button();
            operator_div = new Button();
            Result_box = new TextBox();
            Resetbtn = new Button();
            Result_exp = new TextBox();
            SuspendLayout();
            // 
            // Input_1
            // 
            Input_1.Cursor = Cursors.Hand;
            Input_1.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_1.Location = new Point(158, 410);
            Input_1.Name = "Input_1";
            Input_1.Size = new Size(79, 57);
            Input_1.TabIndex = 1;
            Input_1.Text = "1";
            Input_1.UseVisualStyleBackColor = true;
            Input_1.Click += Input_1_Click;
            // 
            // Input_2
            // 
            Input_2.Cursor = Cursors.Hand;
            Input_2.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_2.Location = new Point(261, 410);
            Input_2.Name = "Input_2";
            Input_2.Size = new Size(79, 57);
            Input_2.TabIndex = 2;
            Input_2.Text = "2";
            Input_2.UseVisualStyleBackColor = true;
            Input_2.Click += Input_2_Click;
            // 
            // Operator_plus
            // 
            Operator_plus.BackColor = Color.DarkOrange;
            Operator_plus.Cursor = Cursors.Hand;
            Operator_plus.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Operator_plus.Location = new Point(474, 145);
            Operator_plus.Name = "Operator_plus";
            Operator_plus.Size = new Size(76, 57);
            Operator_plus.TabIndex = 3;
            Operator_plus.Text = "+";
            Operator_plus.UseVisualStyleBackColor = false;
            Operator_plus.Click += Operator_plus_Click;
            // 
            // Operator_equal
            // 
            Operator_equal.BackColor = Color.DarkOrange;
            Operator_equal.Cursor = Cursors.Hand;
            Operator_equal.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Operator_equal.Location = new Point(474, 492);
            Operator_equal.Name = "Operator_equal";
            Operator_equal.Size = new Size(76, 57);
            Operator_equal.TabIndex = 4;
            Operator_equal.Text = "=";
            Operator_equal.UseVisualStyleBackColor = false;
            Operator_equal.Click += Operator_equal_Click;
            // 
            // Input_3
            // 
            Input_3.Cursor = Cursors.Hand;
            Input_3.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_3.Location = new Point(366, 410);
            Input_3.Name = "Input_3";
            Input_3.Size = new Size(79, 57);
            Input_3.TabIndex = 5;
            Input_3.Text = "3";
            Input_3.UseVisualStyleBackColor = true;
            Input_3.Click += Input_3_Click;
            // 
            // Input_4
            // 
            Input_4.Cursor = Cursors.Hand;
            Input_4.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_4.Location = new Point(158, 320);
            Input_4.Name = "Input_4";
            Input_4.Size = new Size(79, 57);
            Input_4.TabIndex = 6;
            Input_4.Text = "4";
            Input_4.UseVisualStyleBackColor = true;
            Input_4.Click += Input_4_Click;
            // 
            // Input_5
            // 
            Input_5.Cursor = Cursors.Hand;
            Input_5.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_5.Location = new Point(261, 320);
            Input_5.Name = "Input_5";
            Input_5.Size = new Size(79, 57);
            Input_5.TabIndex = 7;
            Input_5.Text = "5";
            Input_5.UseVisualStyleBackColor = true;
            Input_5.Click += Input_5_Click;
            // 
            // Input_6
            // 
            Input_6.Cursor = Cursors.Hand;
            Input_6.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_6.Location = new Point(366, 320);
            Input_6.Name = "Input_6";
            Input_6.Size = new Size(79, 57);
            Input_6.TabIndex = 8;
            Input_6.Text = "6";
            Input_6.UseVisualStyleBackColor = true;
            Input_6.Click += Input_6_Click;
            // 
            // Input_7
            // 
            Input_7.Cursor = Cursors.Hand;
            Input_7.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_7.Location = new Point(158, 226);
            Input_7.Name = "Input_7";
            Input_7.Size = new Size(79, 57);
            Input_7.TabIndex = 9;
            Input_7.Text = "7";
            Input_7.UseVisualStyleBackColor = true;
            Input_7.Click += Input_7_Click;
            // 
            // Input_8
            // 
            Input_8.Cursor = Cursors.Hand;
            Input_8.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_8.Location = new Point(261, 226);
            Input_8.Name = "Input_8";
            Input_8.Size = new Size(79, 57);
            Input_8.TabIndex = 10;
            Input_8.Text = "8";
            Input_8.UseVisualStyleBackColor = true;
            Input_8.Click += Input_8_Click;
            // 
            // Input_9
            // 
            Input_9.Cursor = Cursors.Hand;
            Input_9.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_9.Location = new Point(366, 226);
            Input_9.Name = "Input_9";
            Input_9.Size = new Size(79, 57);
            Input_9.TabIndex = 11;
            Input_9.Text = "9";
            Input_9.UseVisualStyleBackColor = true;
            Input_9.Click += Input_9_Click;
            // 
            // Input_0
            // 
            Input_0.Cursor = Cursors.Hand;
            Input_0.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Input_0.Location = new Point(158, 492);
            Input_0.Name = "Input_0";
            Input_0.Size = new Size(79, 57);
            Input_0.TabIndex = 12;
            Input_0.Text = "0";
            Input_0.UseVisualStyleBackColor = true;
            Input_0.Click += Input_0_Click;
            // 
            // operator_minus
            // 
            operator_minus.BackColor = Color.DarkOrange;
            operator_minus.Cursor = Cursors.Hand;
            operator_minus.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            operator_minus.Location = new Point(474, 226);
            operator_minus.Name = "operator_minus";
            operator_minus.Size = new Size(76, 57);
            operator_minus.TabIndex = 13;
            operator_minus.Text = "-";
            operator_minus.UseVisualStyleBackColor = false;
            operator_minus.Click += operator_minus_Click;
            // 
            // operator_multi
            // 
            operator_multi.BackColor = Color.DarkOrange;
            operator_multi.Cursor = Cursors.Hand;
            operator_multi.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            operator_multi.Location = new Point(474, 320);
            operator_multi.Name = "operator_multi";
            operator_multi.Size = new Size(76, 57);
            operator_multi.TabIndex = 14;
            operator_multi.Text = "*";
            operator_multi.UseVisualStyleBackColor = false;
            operator_multi.Click += operator_multi_Click;
            // 
            // operator_div
            // 
            operator_div.BackColor = Color.DarkOrange;
            operator_div.Cursor = Cursors.Hand;
            operator_div.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            operator_div.Location = new Point(474, 410);
            operator_div.Name = "operator_div";
            operator_div.Size = new Size(76, 57);
            operator_div.TabIndex = 15;
            operator_div.Text = "/";
            operator_div.UseVisualStyleBackColor = false;
            operator_div.Click += operator_div_Click;
            // 
            // Result_box
            // 
            Result_box.BackColor = Color.Black;
            Result_box.BorderStyle = BorderStyle.None;
            Result_box.Font = new Font("メイリオ", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Result_box.ForeColor = SystemColors.Window;
            Result_box.Location = new Point(55, 89);
            Result_box.Name = "Result_box";
            Result_box.Size = new Size(643, 41);
            Result_box.TabIndex = 16;
            Result_box.Text = "0";
            Result_box.TextAlign = HorizontalAlignment.Right;
            Result_box.TextChanged += Result_box_TextChanged;
            // 
            // Resetbtn
            // 
            Resetbtn.BackColor = Color.DarkGray;
            Resetbtn.Cursor = Cursors.Hand;
            Resetbtn.Font = new Font("メイリオ", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Resetbtn.Location = new Point(158, 145);
            Resetbtn.Name = "Resetbtn";
            Resetbtn.Size = new Size(79, 57);
            Resetbtn.TabIndex = 17;
            Resetbtn.Text = "C";
            Resetbtn.UseVisualStyleBackColor = false;
            Resetbtn.Click += Resetbtn_Click;
            // 
            // Result_exp
            // 
            Result_exp.BackColor = Color.Black;
            Result_exp.BorderStyle = BorderStyle.None;
            Result_exp.Font = new Font("メイリオ", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 128);
            Result_exp.ForeColor = SystemColors.Window;
            Result_exp.Location = new Point(55, 25);
            Result_exp.Name = "Result_exp";
            Result_exp.Size = new Size(643, 41);
            Result_exp.TabIndex = 18;
            Result_exp.TextAlign = HorizontalAlignment.Right;
            Result_exp.TextChanged += Result_exp_TextChanged;
            // 
            // Calculator
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(742, 595);
            Controls.Add(Result_exp);
            Controls.Add(Resetbtn);
            Controls.Add(Result_box);
            Controls.Add(operator_div);
            Controls.Add(operator_multi);
            Controls.Add(operator_minus);
            Controls.Add(Input_0);
            Controls.Add(Input_9);
            Controls.Add(Input_8);
            Controls.Add(Input_7);
            Controls.Add(Input_6);
            Controls.Add(Input_5);
            Controls.Add(Input_4);
            Controls.Add(Input_3);
            Controls.Add(Operator_equal);
            Controls.Add(Operator_plus);
            Controls.Add(Input_2);
            Controls.Add(Input_1);
            Name = "Calculator";
            Text = "Calculator";
            Load += Form1_Load;
            BackColorChanged += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button Input_1;
        private Button Input_2;
        private Button Operator_plus;
        private Button Operator_equal;
        private Button Input_3;
        private Button Input_4;
        private Button Input_5;
        private Button Input_6;
        private Button Input_7;
        private Button Input_8;
        private Button Input_9;
        private Button Input_0;
        private Button operator_minus;
        private Button operator_multi;
        private Button operator_div;
        private TextBox Result_box;
        private Button Resetbtn;
        private TextBox Result_exp;
    }
}
